import React, { useState, useEffect } from "react";

const moods = [
  { label: "Happy", color: "#4caf50", emoji: "😊" },
  { label: "Neutral", color: "#ffb300", emoji: "😐" },
  { label: "Sad", color: "#f44336", emoji: "😢" },
  { label: "Anxious", color: "#9c27b0", emoji: "😰" },
  { label: "Calm", color: "#2196f3", emoji: "😌" },
];

const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function getWeekDates() {
  const now = new Date();
  const day = now.getDay();
  const sunday = new Date(now);
  sunday.setDate(now.getDate() - day);
  return Array(7)
    .fill(null)
    .map((_, i) => {
      const d = new Date(sunday);
      d.setDate(sunday.getDate() + i);
      return d;
    });
}

function formatDate(date) {
  return date.toISOString().slice(0, 10);
}

export default function WeeklyJournalApp() {
  const [entries, setEntries] = useState(() => {
    const saved = localStorage.getItem("weekly-journal-entries");
    return saved ? JSON.parse(saved) : {};
  });

  const [selectedDate, setSelectedDate] = useState(formatDate(new Date()));
  const [text, setText] = useState("");
  const [tags, setTags] = useState("");
  const [mood, setMood] = useState(null);

  useEffect(() => {
    localStorage.setItem("weekly-journal-entries", JSON.stringify(entries));
  }, [entries]);

  useEffect(() => {
    const entry = entries[selectedDate];
    setText(entry?.text || "");
    setTags(entry?.tags?.join(", ") || "");
    setMood(entry?.mood || null);
  }, [selectedDate, entries]);

  function saveEntry() {
    if (!mood) {
      alert("Please select a mood before saving.");
      return;
    }
    const newEntry = {
      text,
      tags: tags.split(",").map((t) => t.trim()).filter((t) => t.length > 0),
      mood,
    };
    setEntries((prev) => ({ ...prev, [selectedDate]: newEntry }));
    alert("Entry saved!");
  }

  function deleteEntry() {
    if (entries[selectedDate]) {
      const { [selectedDate]: _, ...rest } = entries;
      setEntries(rest);
      setText("");
      setTags("");
      setMood(null);
      alert("Entry deleted!");
    }
  }

  const weekDates = getWeekDates();
  const moodCounts = moods.reduce((acc, m) => {
    acc[m.label] = 0;
    return acc;
  }, {});
  weekDates.forEach((d) => {
    const entry = entries[formatDate(d)];
    if (entry && entry.mood) moodCounts[entry.mood]++;
  });

  return (
    <div style={styles.app}>
      <header style={styles.header}>
        <h1>Weekly Mental Health Journal</h1>
        <p>Track your moods and thoughts, weekly overview & mood chart</p>
      </header>

      <nav style={styles.nav}>
        {weekDates.map((d) => {
          const dateStr = formatDate(d);
          const isSelected = dateStr === selectedDate;
          const entry = entries[dateStr];
          return (
            <button
              key={dateStr}
              onClick={() => setSelectedDate(dateStr)}
              style={{
                ...styles.navButton,
                ...(isSelected ? styles.navButtonActive : {}),
                borderColor: entry?.mood
                  ? moods.find((m) => m.label === entry.mood)?.color
                  : "#ccc",
              }}
              aria-label={`Select ${d.toDateString()}`}
            >
              <div>{daysOfWeek[d.getDay()]}</div>
              <div style={{ fontSize: 12 }}>{d.getDate()}</div>
            </button>
          );
        })}
      </nav>

      <main style={styles.main}>
        <section style={styles.entrySection}>
          <h2>Entry for {new Date(selectedDate).toDateString()}</h2>

          <label style={styles.label}>
            Mood
            <div style={styles.moodSelector}>
              {moods.map((m) => (
                <button
                  key={m.label}
                  onClick={() => setMood(m.label)}
                  style={{
                    ...styles.moodButton,
                    backgroundColor: m.color,
                    opacity: mood === m.label ? 1 : 0.5,
                    cursor: "pointer",
                  }}
                  aria-pressed={mood === m.label}
                  title={m.label}
                >
                  {m.emoji}
                </button>
              ))}
            </div>
          </label>

          <label style={styles.label}>
            Journal Text
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Write about your day..."
              style={styles.textarea}
              rows={6}
            />
          </label>

          <label style={styles.label}>
            Tags (comma separated)
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="e.g. work, anxiety, happy"
              style={styles.input}
            />
          </label>

          <div style={styles.buttonRow}>
            <button style={styles.saveButton} onClick={saveEntry}>
              Save Entry
            </button>
            <button
              style={styles.deleteButton}
              onClick={deleteEntry}
              disabled={!entries[selectedDate]}
            >
              Delete Entry
            </button>
          </div>
        </section>

        <section style={styles.chartSection}>
          <h2>Mood Chart - This Week</h2>
          <div style={styles.chart}>
            {moods.map((m) => {
              const count = moodCounts[m.label];
              return (
                <div key={m.label} style={styles.chartBarContainer}>
                  <div
                    style={{
                      ...styles.chartBar,
                      height: count * 30,
                      backgroundColor: m.color,
                    }}
                    title={`${m.label}: ${count}`}
                  />
                  <div style={styles.chartLabel}>{m.emoji}</div>
                </div>
              );
            })}
          </div>
        </section>
      </main>

      <footer style={styles.footer}>
        <small>© 2025 Mental Health Journal App</small>
      </footer>
    </div>
  );
}

const styles = {
  app: {
    fontFamily: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
    maxWidth: 900,
    margin: "auto",
    padding: 20,
    backgroundColor: "#f9fafb",
    color: "#333",
    minHeight: "100vh",
    display: "flex",
    flexDirection: "column",
  },
  header: {
    textAlign: "center",
    marginBottom: 20,
  },
  nav: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  navButton: {
    flex: 1,
    margin: "0 4px",
    padding: 8,
    borderRadius: 8,
    border: "2px solid #ccc",
    backgroundColor: "#fff",
    cursor: "pointer",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    transition: "all 0.3s ease",
    userSelect: "none",
  },
  navButtonActive: {
    borderColor: "#1976d2",
    backgroundColor: "#e3f2fd",
    fontWeight: "bold",
  },
  main: {
    flex: 1,
    display: "flex",
    gap: 24,
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  entrySection: {
    flex: "1 1 400px",
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    display: "flex",
    flexDirection: "column",
  },
  label: {
    marginBottom: 12,
    fontWeight: "600",
    display: "flex",
    flexDirection: "column",
  },
  moodSelector: {
    display: "flex",
    gap: 12,
    marginTop: 8,
  },
  moodButton: {
    border: "none",
    borderRadius: "50%",
    width: 36,
    height: 36,
    fontSize: 20,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
    transition: "opacity 0.2s",
  },
  textarea: {
    resize: "vertical",
    padding: 8,
    borderRadius: 6,
    border: "1px solid #ccc",
    fontSize: 16,
    fontFamily: "inherit",
  },
  input: {
    padding: 8,
    borderRadius: 6,
    border: "1px solid #ccc",
    fontSize: 16,
    fontFamily: "inherit",
  },
  buttonRow: {
    marginTop: 12,
    display: "flex",
    gap: 12,
  },
  saveButton: {
    backgroundColor: "#1976d2",
    border: "none",
    padding: "10px 18px",
    borderRadius: 6,
    color: "#fff",
    fontWeight: "600",
    cursor: "pointer",
    flex: 1,
    transition: "background-color 0.3s ease",
  },
  deleteButton: {
    backgroundColor: "#f44336",
    border: "none",
    padding: "10px 18px",
    borderRadius: 6,
    color: "#fff",
    fontWeight: "600",
    cursor: "pointer",
    flex: 1,
    opacity: 1,
    transition: "opacity 0.3s ease",
  },
  chartSection: {
    flex: "1 1 300px",
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    boxShadow: "0 2px 6px rgba(0,0,0,0.1)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  chart: {
    display: "flex",
    alignItems: "flex-end",
    gap: 16,
    height: 150,
    marginTop: 20,
    width: "100%",
    justifyContent: "center",
  },
  chartBarContainer: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: 30,
  },
  chartBar: {
    width: "100%",
    borderRadius: 6,
    transition: "height 0.3s ease",
  },
  chartLabel: {
    marginTop: 6,
    fontSize: 18,
  },
  footer: {
    textAlign: "center",
    padding: 12,
    fontSize: 12,
    color: "#888",
  },
};
